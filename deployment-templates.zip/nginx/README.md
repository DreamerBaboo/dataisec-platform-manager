# Nginx Deployment Template

基本的 Nginx 部署模板，支持以下配置：
- 可配置副本數
- CPU 和內存資源限制
- 鏡像版本選擇
- 命名空間設置

## 使用說明
1. 設置適當的資源限制
2. 選擇所需的 Nginx 版本
3. 根據需求調整副本數 